<?php 

$servidor = "localhost";
$usuario = "root";
$senha = "";
$bd = "infoVirus";

// Função de conexão com mysqli
$conexao = mysqli_connect($servidor, $usuario, $senha, $bd);
?>