<form action="../control/comHash.php" method="post" enctype="multipart/form-data">

<div class="comparator-box">
    <label class="upload-btn">
        SELECIONE O PRIMEIRO ARQUIVO
        <input type="file" class="file-input" name="arquivo1"/>
    </label>
    <div class="upload-icon">
        <ion-icon name="swap-horizontal-outline"></ion-icon>
    </div>
    <label class="upload-btn">
        SELECIONE O SEGUNDO ARQUIVO
        <input type="file" class="file-input" name="arquivo2"/>
    </label>
    <p>ou</p>
    <p>Arraste os arquivos que você gostaria de comparar para que possamos realizar a verificação.</p>
</div>



<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <div class="button-container">
<button type="submit"class="test-button">Testar</button></div>
</form>


