<form action="../control/url.php" method="post">
<div class="input-box">
    <center> <ion-icon name="wifi"></ion-icon> <br> </center>
    <input type="text" placeholder="Informe a URL para verificação de vírus" name="furl">
</div>

<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <br> <br> <br>
    <center> <button type="submit"class="test-button">Escanear</button></div> </center>
    
    <div class="button-container">



</form>