<form action="../control/senha.php" method="post">
<div class="input-box">
    <center> 
        <ion-icon name="lock-closed-outline"></ion-icon>
        <br>
    </center>
    <input type="text" placeholder="Digite a senha para verificação de vulnerabilidades" name="fsenha">
</div>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <div class="button-container">
<button type="submit"class="test-button">Testar</button></div>
</form>