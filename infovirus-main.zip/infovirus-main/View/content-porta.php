<form action="../control/escaneia_porta.php" method="get">
<div class="input-box">
    <center > 
    <ion-icon name="log-in-outline"></ion-icon>
        <br>
        Clique para escanear serviços e versões das portas abertas no momento.
</center>
    </div>
    <div class="button-container">
    <button type="submit" class="test-button">Escanear Portas</button> 
</div>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>

<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</form>